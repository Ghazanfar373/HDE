# <publisher_name> <ownership_strength> <nb_iterations> <stop_subscriber_flag>
echo ../exec/OwnershipDataPublisher $*
../exec/OwnershipDataPublisher $*