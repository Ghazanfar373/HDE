#ifndef NN_ERROR_H
#define NN_ERROR_H

#define NN_ERR_INVALID -1
#define NN_ERR_OUT_OF_MEMORY -2

#endif /* NN_ERROR_H */
