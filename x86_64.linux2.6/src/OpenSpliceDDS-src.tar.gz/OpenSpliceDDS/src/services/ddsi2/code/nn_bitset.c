#include "nn_bitset.h"

#if ! NN_HAVE_C99_INLINE
#include "nn_bitset.template"
#endif
